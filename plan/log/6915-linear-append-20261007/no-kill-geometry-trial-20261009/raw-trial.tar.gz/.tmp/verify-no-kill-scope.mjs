import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
const path = "scripts/hooks/run-linear-append-provenance.mjs";
const base = "e33560ce57c5912fd75cc36c7156b1037828416e";
const original = execFileSync("git", ["show", `${base}:${path}`]).toString();
const candidate = readFileSync(path, "utf8");
const hash = (value) => createHash("sha256").update(value).digest("hex");
assert.equal(hash(original), "aefbb190424ca7d9b22ebf11640662f63ff5917bd16553f6a909fcccda65cf3d");
const segment = (text, start, end) => {
  const first = text.indexOf(start), last = text.indexOf(end, first);
  assert(first >= 0 && last > first, `missing anchors: ${start}`);
  return text.slice(first, last);
};
let restored = candidate;
const replace = (changed, old) => { assert(restored.includes(changed)); restored = restored.replace(changed, old); };
replace('import { EventEmitter } from "node:events";\n', "");
replace(segment(restored, "// Private supervision seam:", "async function runAppendQualification()"), "");
replace("  let before, supervision;", "  let before;");
const report = '    try {\n      if (existsSync(reportPath)) {';
const originalSupervision = segment(original, "    const start = Date.now();", report);
const candidateSupervision = segment(restored, "    supervision = superviseAppendChild({", report);
// Exact old spawn arguments/options survive the helper extraction.
const oldSpawnOptions = segment(originalSupervision, '      cwd: checkout.root,', '    });');
const newSpawnOptions = segment(candidateSupervision, '          cwd: checkout.root,', '        }),');
assert.equal(newSpawnOptions.replace(/^    /gm, ""), oldSpawnOptions);
assert.equal((candidate.slice(0, candidate.indexOf("async function selfTest()")).match(/\bspawn\(/g) ?? []).length, 1);
replace(candidateSupervision, originalSupervision);
const cleanupStart = '  } finally {\n    // Defensive barrier also covers every handled post-spawn exceptional path.';
const cleanupEnd = '  console.log(`6915 parent: evidence retained at ${archive}`);';
const candidateCleanup = segment(restored, cleanupStart, cleanupEnd);
const originalCleanup = segment(original, '  } finally {\n    try {\n      const after = assertFrozenInputs(checkout);', cleanupEnd);
const inner = segment(candidateCleanup, '    const finalize = () => {\n', '    };\n    if (supervision === undefined) finalize();').slice('    const finalize = () => {\n'.length);
assert.equal(inner.replace(/^  /gm, ""), originalCleanup.slice('  } finally {\n'.length, -'  }\n'.length), "original independent custody/FD/lock cleanup changed");
assert(candidateCleanup.indexOf("await supervision.waitForClose()") < candidateCleanup.indexOf("const finalize"));
replace(candidateCleanup, originalCleanup);
const tailEnd = '  if (errors.length) throw new AggregateError(errors, "6915 parent qualification failed", { cause: errors[0] });';
const originalArchive = segment(original, '  try {\n    save("runner-errors.v8"', tailEnd);
const candidateArchive = segment(restored, '  if (supervision === undefined) {\n    try {\n      save("runner-errors.v8"', tailEnd);
const preChildArchive = segment(candidateArchive, '    try {\n      save("runner-errors.v8"', '  } else');
assert.equal(preChildArchive.replace(/^  /gm, ""), originalArchive, "original pre-child archive changed");
replace(candidateArchive, originalArchive);
replace("async function selfTest()", "function selfTest()");
replace(segment(restored, "  // Exercise the actual production supervisor with inert events, timers and", "  console.log(`6915 parent self-test:"), "");
replace('if (process.argv.length === 3 && process.argv[2] === "--self-test") await selfTest();', 'if (process.argv.length === 3 && process.argv[2] === "--self-test") selfTest();');
assert.equal(restored, original, "bytes outside released supervision/capture/close-order and inert controls changed");
for (const [label, start, end] of [
  ["approval/pins/config/identity/source custody/parser/codec/validators/environment", "const APPROVAL_COMMIT", "// Private supervision seam:"],
  ["unchanged child reporter/parser/validator archival", report, '  } catch (error) {\n    errors.push(error);\n  } finally {'],
]) {
  const bytes = segment(candidate, start, end);
  const predecessorEnd = end === "// Private supervision seam:" ? "async function runAppendQualification()" : end;
  assert.equal(bytes, segment(original, start, predecessorEnd));
  console.log(`${label}: ${Buffer.byteLength(bytes)} bytes SHA256 ${hash(bytes)}`);
}
const oldControls = segment(original, "function selfTest()", "\nif (process.argv[1]");
console.log(`159 original controls restored exactly: SHA256 ${hash(oldControls)}`);
console.log(`predecessor/restored: ${Buffer.byteLength(restored)} bytes SHA256 ${hash(restored)}`);
console.log(`candidate: ${Buffer.byteLength(candidate)} bytes SHA256 ${hash(candidate)}`);
const production = candidate.slice(0, candidate.indexOf("async function selfTest()"));
assert(!/\b(?:kill|abort|destroy|unref)\s*\(|SIGKILL|Promise\.race\(/.test(production), "alternate termination/early-finalization path");
assert(production.includes("cap = OUTPUT_CAP") && production.includes("deadline = TIMEOUT_MS"));
console.log("exact inverse-edit proof and zero-termination static checks passed");
