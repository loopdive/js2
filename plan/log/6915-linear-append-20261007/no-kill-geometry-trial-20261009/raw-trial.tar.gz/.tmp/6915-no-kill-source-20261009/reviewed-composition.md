# Reviewed append composition — no runtime authorization

Committed execution candidate: 7ea1ee6e2488649b244874616de609f16ccdfcd2.
Compiler source tree: 171606514a3cf6733e82eb11549a659856d68c1a.
Original-owner runner commit: 3671c4f0536cafaef31aac3405d944306456a050.
Normal integration commit: 0083aabb867c3bd2bb7c28b612f14ea9c80730fe.

Independent Astra review cleared the complete released runner diff and the
single-literal comparator rebinding. Parent actual terminal exit0: 197 runner
controls and 62 comparison controls. These are inert controls, not compiler
runtime evidence. All original controls and baseline failures remain preserved.

Independent Sol physical audit verified every source/config/fixed input against
committed bytes and modes: 1901 source paths, 1915 custody inputs, 42886328
bytes, zero blob/mode errors. Provisional freeze is 219292 bytes, SHA256
d5ffb756f02bb16fd44fcf7c051f90d02909d092dd39537b2dc0c478b3899fe6.
Freezer SHA256:
b8cbb0dc5f99ea77b337263d78a3dee4fcb3437e53f3a4f48947cf2df7377a30.
Freezer differs only in committed HEAD and runner hash from preserved predecessor.
Node v22.23.2 / V8 12.4.254.21-node.56; parent independently invoked pnpm10.30.2.

Mandatory separate bindings, not fields in the provisional freeze schema:

- Runner SHA256: ddf52b81471015d7ead47a7fb222292c0ba1c8ca94dbc4a2be6b3440b63d5322.
- Comparator SHA256: 4127be624740255181b1339938bc5416e19f2a15905dbea60ee2a9821e598742.
- Baseline compressed graphs SHA256: d4d16070532de2c5dc7aa59d35f0e4ccd0ebbb7e1bc7335a1c8a0da820c6ef59.
- Baseline decompressed graphs SHA256: bb1f7239ff371e6f373d3b45450a458f88c319a2d47b397b080681ce1d8f2b3e.

This is private reviewed custody evidence, not child execution, trial release,
source equality, native admission, performance, main delivery or retirement.
The separately authorized one trial must recheck all bindings and actual HEAD,
wait for the verified live unrelated suite to finish, preserve complete raw
capture and retain natural-close behavior on every fault. Actual parent terminal
exit0 and empty receipt.failures remain mandatory; capture.json is diagnostic.
No retry, termination, HOLD removal or queue release is authorized here.
Future publication identity must not be substituted for this execution identity.
