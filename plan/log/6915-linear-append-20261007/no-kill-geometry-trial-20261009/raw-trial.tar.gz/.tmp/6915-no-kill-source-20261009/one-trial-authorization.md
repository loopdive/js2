# B parent one-trial authorization

Authorize exactly one local append trial through the existing reviewed runner
at committed execution HEAD7ea1ee6e2488649b244874616de609f16ccdfcd2, source1716.
This implements issue6915's separately parent-authorized serialized trial;
it is not a new source release, retry, CI action or acceptance decision.

Independent full source/input audit, Astra runner/comparator inverse reviews,
parent197 supervisor and62 comparator controls passed. Full bindings are in
reviewed-composition.md. Before spawn, immediate-pretrial-freeze.json must be
byte-identical to reviewed provisional-freeze.json SHA256
d5ffb756f02bb16fd44fcf7c051f90d02909d092dd39537b2dc0c478b3899fe6,
and expected.json must exactly equal its nine-field manifest.

Other suite supervisor89588 and parent89604 disappeared; authoritative retained
terminal.json records natural child code1/signalnull, ended2026-10-09T12:22:39.231Z,
complete capture and unchanged custody. No other live compiler-test process was
found. These are slot-release evidence, not an IR acceptance result.

Use unchanged runner bytesddf52, comparator4127, Node22.23.2, V8
12.4.254.21-node.56, pnpm10.30.2, original command and flags. Preserve all prior
evidence. Capture actual parent terminal code and complete raw child evidence;
require unfiltered complete graph equality, full custody equality and empty
receipt.failures. capture.json is diagnostics only. Any fault or difference
holds acceptance; no automatic termination, retry, rebaseline or normalization.
Wait for natural close even after fault; actual termination requires human
authority. No native completion, performance, HOLD removal, main delivery or
legacy retirement is authorized by this trial.
