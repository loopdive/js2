import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, lstatSync } from "node:fs";
import { resolve } from "node:path";
import { gunzipSync } from "node:zlib";
const git = (...args) => execFileSync("git", args, { maxBuffer: 16 * 1024 * 1024 });
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const archive = "plan/log/6915-linear-append-20261007/ci-trusted-parent-20261008/";
const old = name => JSON.parse(gunzipSync(readFileSync(`${archive}${name}.json.gz`)));
const head = git("rev-parse", "HEAD").toString().trim();
assert.equal(head, "7ea1ee6e2488649b244874616de609f16ccdfcd2");
const sourceTree = git("rev-parse", "HEAD:src").toString().trim();
assert.equal(sourceTree, "171606514a3cf6733e82eb11549a659856d68c1a");
const paths = git("ls-tree", "-r", "HEAD", "--", "src").toString().trim().split("\n").map(line => {
  const entry = /^(100644|100755) blob [a-f0-9]{40}\t(.+)$/.exec(line);
  assert.ok(entry, `unsupported source: ${line}`); return entry[2];
});
const configs = ["package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml", "scripts/test262-concurrency.mjs", "tsconfig.json", "tsconfig.ts7.json", "vite.config.lib.ts", "vite.config.ts", "vitest.config.ts"];
const extra = ["tests/issue-6915-linear-owned-ascii-append-copy-kernel.test.ts", "website/public/benchmarks/competitive/programs/string-hash.js", "scripts/hooks/run-linear-append-provenance.mjs", "scripts/hooks/changed-root-tests.sh", "plan/issues/6915-linear-owned-ascii-append-copy-kernel.md"];
const files = {};
for (const path of [...paths, ...configs, ...extra]) {
  const stat = lstatSync(path); assert.ok(stat.isFile() && !stat.isSymbolicLink());
  const bytes = readFileSync(path); assert.ok(bytes.equals(git("show", `${head}:${path}`)), `dirty ${path}`);
  files[path] = sha(bytes);
}
for (const path of configs) assert.equal(files[path], old("before").files[path]);
const runnerPath = resolve("scripts/hooks/run-linear-append-provenance.mjs");
const runnerSha256 = sha(readFileSync(runnerPath));
assert.equal(runnerSha256, "ddf52b81471015d7ead47a7fb222292c0ba1c8ca94dbc4a2be6b3440b63d5322");
assert.equal(sha(readFileSync(".github/workflows/ci.yml")), "ac3e43b9422b96fb550471e86885ddbf1ce036058b80daa93f51b34e1ee43dd1");
const manifest = { ...old("expected"), head, sourceTree };
const fixed = { runtime: "src/codegen-linear/runtime.ts", consumer: "src/ir/backend/frozen-body-consumer.ts", integration: "src/ir/backend/linear-integration.ts", testSha256: extra[0], fixture: extra[1] };
for (const [key, path] of Object.entries(fixed)) assert.equal(files[path], manifest[key]);
const toolchain = { node: process.version, v8: process.versions.v8 };
assert.deepEqual(toolchain, { node: "v22.23.2", v8: "12.4.254.21-node.56" });
const pnpm = execFileSync("pnpm", ["--version"]).toString().trim(); assert.equal(pnpm, "10.30.2");
console.log(JSON.stringify({ head, sourceTree, sourceFiles: paths.length, runnerPath, runnerSha256, toolchain, pnpm, command: old("command"), manifest, files }, null, 2));
