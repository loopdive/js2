import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
const archive = ".tmp/6915-ci/run-jAbJqK";
const original = gunzipSync(readFileSync("plan/log/6915-linear-append-20261007/repaired-v3.log.gz")).toString();
const previous = original.split("\n").filter(line => line.startsWith('{"schema":')).map(line => JSON.parse(line));
const current = readFileSync(`${archive}/graphs.ndjson`, "utf8").trim().split("\n").map(line => JSON.parse(line));
assert.equal(previous.length, 38);
assert.equal(current.length, 38);
assert.ok(current.every(row => row.schema === "6915-evidence-graph-v1"));
assert.equal(current[0].kind, "provenance");
assert.equal(current[37].kind, "completion");
assert.equal(new Set(current.slice(1, 37).map(row => row.id)).size, 36);
assert.deepEqual(current.slice(1), previous.slice(1));
const reporter = JSON.parse(readFileSync(`${archive}/reporter.json`, "utf8"));
for (const [key, expected] of Object.entries({ numTotalTests: 36, numPassedTests: 36, numFailedTests: 0, numPendingTests: 0, numTodoTests: 0 })) assert.equal(reporter[key], expected);
assert.equal(reporter.success, true);
const receipt = JSON.parse(readFileSync(`${archive}/receipt.json`, "utf8"));
assert.equal(receipt.code, 0);
assert.equal(receipt.signal, null);
assert.equal(receipt.killed, false);
assert.equal(receipt.spawnError, null);
assert.deepEqual(receipt.failures, []);
const before = JSON.parse(readFileSync(`${archive}/before.json`, "utf8"));
const after = JSON.parse(readFileSync(`${archive}/after.json`, "utf8"));
assert.deepEqual(after, before);
assert.equal(before.head, "0d2dfddb4b1145097210f5398e535e550f945f82");
assert.equal(before.sourceTree, "953f74f80cf2f8085b8e1c93489fcdd357929b37");
console.log(JSON.stringify({
  executionHead: before.head, sourceTree: before.sourceTree,
  lane: "existing public Linear overlay; not the unpublished native caller",
  harness: "trusted local parent, approved 4096-MiB strict forks",
  reporter: { passed: 36, failed: 0, skipped: 0, todo: 0 },
  graphEnvelopes: 38, exactObservationGraphs: 36, exactCompletionGraph: true,
  comparedAgainst: "archived narrowly repaired v3 baseline",
  filteredGraphFields: [],
  executionProvenance: "separately retained and validated; intentionally different epoch/command/flags",
  beforeAfterCustodyEqual: true,
  elapsedMs: receipt.elapsedMs,
  limitations: "No native array/Unicode completion, append performance benefit, migration closure, main delivery or hold release. Original failures and fixtures remain unchanged."
}, null, 2));
