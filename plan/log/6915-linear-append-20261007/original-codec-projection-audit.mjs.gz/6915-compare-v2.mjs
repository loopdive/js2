import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const worker = '/private/tmp/js2-6915-linear-append-tests-20261007';
const original = gunzipSync(readFileSync('plan/log/6915-linear-append-20261007/original-regression.log.gz')).toString();
const current = readFileSync(`${worker}/.tmp/6915-validation/repaired-v2.log`, 'utf8');
const oldRows = original.split('\n').filter(x => x.startsWith('{"kind":')).map(x => JSON.parse(x));
const envelopes = current.split('\n').filter(x => x.startsWith('{"schema":')).map(x => JSON.parse(x));
function decode(graph) {
  const objects = graph.nodes.map((node, index) => {
    assert.equal(node.id, index);
    if (node.kind === 'array') return [];
    if (node.kind === 'map') return new Map();
    if (node.kind === 'set') return new Set();
    if (node.kind === 'array-buffer') {
      const bytes = Buffer.from(node.bytesBase64, 'base64');
      assert.equal(bytes.length, node.byteLength);
      return Uint8Array.from(bytes).buffer;
    }
    if (node.kind === 'typed-array' || node.kind === 'data-view') return { bytesBase64: node.bytesBase64 };
    assert.ok(['object', 'error'].includes(node.kind));
    return Object.create(null);
  });
  const value = atom => {
    if (atom === null || typeof atom !== 'object') return atom;
    if ('ref' in atom) {
      assert.ok(Number.isInteger(atom.ref) && atom.ref >= 0 && atom.ref < objects.length);
      return objects[atom.ref];
    }
    if (atom.tag === 'undefined') return undefined;
    if (atom.tag === 'bigint') return BigInt(atom.decimal);
    assert.equal(atom.tag, 'number');
    assert.ok(['nan', '+infinity', '-infinity', '-0'].includes(atom.value));
    return ({ nan: NaN, '+infinity': Infinity, '-infinity': -Infinity, '-0': -0 })[atom.value];
  };
  for (const node of graph.nodes) {
    const object = objects[node.id];
    for (const property of node.properties) {
      assert.ok(property.descriptor === 'data' || property.descriptor === 'native-error-stack');
      if (property.descriptor === 'native-error-stack') {
        assert.equal(node.kind, 'error'); assert.equal(property.key, 'stack');
        assert.equal(property.getter, 'fresh-native-error-getter');
        assert.equal(property.setter, 'fresh-native-error-setter');
        assert.equal(typeof property.value, 'string');
      }
      if (Array.isArray(object) && property.key === 'length') { object.length = value(property.value); continue; }
      Object.defineProperty(object, property.key, { value: value(property.value), enumerable: property.enumerable, configurable: true, writable: true });
    }
    if (node.kind === 'map') { for (const [key, item] of node.entries) object.set(value(key), value(item)); assert.equal(object.size, node.size); }
    if (node.kind === 'set') { for (const item of node.values) object.add(value(item)); assert.equal(object.size, node.size); }
  }
  return value(graph.root);
}
assert.equal(envelopes.length, 38);
assert.ok(envelopes.every(row => row.schema === '6915-evidence-graph-v1'));
const rows = envelopes.map(row => decode(row.graph));
const observations = rows.filter(row => row.kind === 'observation');
assert.equal(observations.length, 36);
assert.equal(new Set(observations.map(row => row.id)).size, 36);
assert.ok(observations.every(row => row.passed && ['action', 'schema', 'emission'].every(key => row[key].status === 'passed')));
const completion = rows.find(row => row.kind === 'completion');
assert.equal(completion.passed, true);
for (const key of ['missing', 'duplicates', 'unexpected', 'failures', 'actionFailures', 'schemaFailures', 'emissionFailures', 'cleanupErrors']) assert.deepEqual(completion[key], []);
const projection = evidence => JSON.parse(JSON.stringify(evidence, (key, value) => {
  if (value instanceof Map) return [...value];
  if (value instanceof Set) return [...value];
  if (value instanceof Uint8Array) return [...value];
  return value;
}));
let constructionsChecked = 0;
for (const observation of observations) {
  const proofs = observation.evidence.kind === 'runtime' ? [observation.evidence] : observation.evidence.stage === 'negative' ? [observation.evidence.original, observation.evidence.corrupted].filter(proof => proof.kind === 'runtime') : [];
  for (const proof of proofs) for (const construction of proof.construction) {
    assert.equal(construction.canonicalPointer, construction.rawPointer + Math.ceil(construction.bytes.length / 8) * 8);
    constructionsChecked++;
  }
}
const compared = [];
for (const old of oldRows.filter(row => row.kind === 'observation')) {
  const fresh = observations.find(row => row.id === old.id);
  assert.ok(fresh);
  const actual = projection(fresh.evidence);
  const expected = structuredClone(old.evidence);
  const proofs = actual.kind === 'runtime' ? [actual] : actual.stage === 'negative' ? [actual.original, actual.corrupted].filter(proof => proof.kind === 'runtime') : [];
  for (const proof of proofs) for (const construction of proof.construction) delete construction.canonicalPointer;
  if (actual.stage === 'negative') { assert.equal(typeof actual.rejection, 'string'); assert.ok(actual.rejection.length > 0); assert.equal(actual.rejection, expected.rejection); }
  assert.deepEqual(actual, expected, `${old.id}: surviving full evidence changed`);
  compared.push({ id: old.id, originallyPassed: old.passed, evidenceSha256: createHash('sha256').update(JSON.stringify(actual)).digest('hex') });
}
assert.equal(compared.length, 29);
assert.equal(compared.filter(row => row.originallyPassed).length, 28);
const repeated = observations.find(row => row.id === 'Runtime22').evidence;
assert.equal(repeated.transitions.length, 33);
assert.deepEqual(repeated.transitions.map(step => step.result.length), Array.from({ length: 33 }, (_, i) => i + 1));
const sources = observations.filter(row => row.id.startsWith('Source'));
assert.equal(sources.length, 4);
const values = [0, 96500, 36729899, 862771296];
for (const [index, row] of sources.entries()) {
  const p = row.evidence;
  assert.equal(p.kind, 'source'); assert.equal(p.expected, values[index]); assert.equal(p.native, values[index]); assert.equal(p.actual, values[index]);
  assert.equal(p.report.frozenBodyBatch, p.receipt.batch); assert.equal(p.report.irModule, p.receipt.batch.module);
  assert.equal(p.receipt.moduleSession, p.module); assert.equal(p.receipt.completed, true); assert.equal(p.receipt.backend, 'linear');
  assert.equal(p.logical.unitId, p.ownerUnitId); assert.equal(p.logical.name, 'run');
  const output = p.receipt.outputs.find(item => item.ownerUnitId === p.ownerUnitId);
  assert.equal(output.func, p.logical); assert.equal(output.body, p.physical.body); assert.equal(p.report.funcs.get(p.ownerUnitId), p.physical);
  assert.ok(p.registrationModules.includes(p.module)); assert.ok(p.module.functions.includes(p.physical));
  assert.equal(p.module.functions[p.binding.index - p.binding.imports], p.binding.helper); assert.ok(p.callIndices.includes(p.binding.index));
}
const negatives = observations.filter(row => row.id.startsWith('Negative'));
assert.equal(negatives.length, 8); assert.ok(negatives.every(row => row.evidence.rejected === true && typeof row.evidence.rejection === 'string' && row.evidence.rejection.length > 0));
console.log(JSON.stringify({ envelopes: 38, observations: 36, originalSurvivorsCompared: 29, originalPassingSurvivors: 28, addedConstructionFieldsVerified: constructionsChecked, repeatedTransitions: 33, sourceValues: values, sameValidatorNegatives: 8, compared, comparisonKind: 'Original JSON codec projection, NOT strict decoded graph equality', strictDecodedEquality: false, representationDifferencesPerProofReportedByIndependentAudit: ['Three charCodeAt NaN instruction values were null in original JSON', 'Four empty Map/Set collections were arrays in original JSON'], excludedComparisonFields: ['construction.canonicalPointer (separately recipe-checked)'], missingOriginalRecordsNotRecovered: ['Source01','Source02','Source03','Source04','Negative02','Negative03','Negative04'], limitation: 'Original codec loses NaN/collection kind/reference identity. Exact artifact/kernel/memory preservation is narrower than decoded graph equality or source-free authority/retirement proof' }, null, 2));
