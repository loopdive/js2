import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
const prior = gunzipSync(readFileSync('plan/log/6915-linear-append-20261007/repaired-v3.log.gz')).toString();
const current = readFileSync('.tmp/6915-validation/composed-main.log', 'utf8');
const rows = text => text.split('\n').filter(line => line.startsWith('{"schema":')).map(line => JSON.parse(line));
const before = rows(prior);
const after = rows(current);
assert.equal(before.length, 38);
assert.equal(after.length, 38);
assert.ok(after.every(row => row.schema === '6915-evidence-graph-v1'));
// The first envelope holds deliberately different execution provenance.
// Every complete observation and completion graph must match without filtering.
assert.deepEqual(after.slice(1), before.slice(1));
const report = JSON.parse(readFileSync('.tmp/6915-validation/composed-main.json', 'utf8'));
assert.equal(report.numTotalTests, 36);
assert.equal(report.numPassedTests, 36);
assert.equal(report.numFailedTests, 0);
assert.equal(report.numPendingTests, 0);
console.log(JSON.stringify({ envelopes: 38, completeObservationGraphsEqual: 36, completionGraphEqual: true, filteredGraphFields: [], passed: 36, failed: 0, skipped: 0, provenance: 'separately retained under composed-main parent input/receipt', executionHead: '352accfce5618a44edc4e2f659dcb38c4b7a5d93' }));
