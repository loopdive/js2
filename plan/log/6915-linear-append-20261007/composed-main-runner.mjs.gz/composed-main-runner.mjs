import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { readFileSync, mkdirSync, openSync, closeSync, writeFileSync } from 'node:fs';

assert.equal(process.cwd(), '/private/tmp/js2-6915-linear-append-plan-20261007');
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
assert.equal(git('branch', '--show-current'), 'codex/6915-linear-append-plan-20261007');
assert.equal(git('rev-parse', 'HEAD'), '352accfce5618a44edc4e2f659dcb38c4b7a5d93');
assert.equal(git('status', '--porcelain', '--', 'src', 'tests'), '');
assert.equal(process.env.NODE_OPTIONS, undefined);
assert.ok(process.env.JS2WASM_LINEAR_IR === undefined || process.env.JS2WASM_LINEAR_IR === '1');
const pins = {
  runtime: '2a562751f9e2c6291944836681b3bc99b402c2d154a88c429ee16013eaf09e0f',
  consumer: '262d9866247af2e2fa18a6f8dbdf9d4a07c37c6ae188eb491a312949e6c60404',
  integration: '8bcc7d6507cb6abd1c4333e43fe5fef015f6649dd788221778aa61e6911c1571',
};
assert.equal(sha('src/codegen-linear/runtime.ts'), pins.runtime);
assert.equal(sha('src/ir/backend/frozen-body-consumer.ts'), pins.consumer);
assert.equal(sha('src/ir/backend/linear-integration.ts'), pins.integration);
const sourceTree = git('rev-parse', 'HEAD:src');
assert.equal(sourceTree, '953f74f80cf2f8085b8e1c93489fcdd357929b37');
const fixture = sha('website/public/benchmarks/competitive/programs/string-hash.js');
assert.equal(fixture, '66a15148fdd960dcbe5d87c25a28d870e8db9d00865483d708f0ca4e6e6e335c');
const testPath = 'tests/issue-6915-linear-owned-ascii-append-copy-kernel.test.ts';
assert.equal(sha(testPath), 'c63e83104b42104c0ea9e7d5d3fb3f6f2cce960a65973cbf342698e8e79d7f8d');
const prefix = '.tmp/6915-validation/composed-main';
const args = ['exec', 'vitest', 'run', testPath, '--pool=forks', '--poolOptions.forks.singleFork=true', '--no-file-parallelism', '--reporter=default', '--reporter=json', `--outputFile=${prefix}.json`];
const command = `pnpm ${args.join(' ')}`;
const expected = { ...pins, sourceTree, fixture, head: git('rev-parse', 'HEAD'), testSha256: sha(testPath), command,
  effectiveFlags: { linearIr: '1', nodeOptions: null, execArgv: ['--max-old-space-size=1024', '--expose-gc', '--conditions', 'node', '--conditions', 'development'] } };
mkdirSync('.tmp/6915-validation', { recursive: true });
writeFileSync(`${prefix}-parent-input.json`, JSON.stringify(expected, null, 2));
const log = openSync(`${prefix}.log`, 'w');
console.log(JSON.stringify({ phase: 'start', expected }));
const result = spawnSync('pnpm', args, { stdio: ['ignore', log, log], env: { ...process.env, JS2WASM_LINEAR_IR: '1', JS2WASM_APPEND_TEST_COMMAND: command, JS2WASM_APPEND_EXPECTED_PROVENANCE: JSON.stringify(expected) } });
closeSync(log);
const receipt = { status: result.status, signal: result.signal, error: result.error?.stack ?? null, expected, testSha256After: sha(testPath), headAfter: git('rev-parse', 'HEAD'), sourceTreeAfter: git('rev-parse', 'HEAD:src') };
writeFileSync(`${prefix}-parent-receipt.json`, JSON.stringify(receipt, null, 2));
assert.equal(receipt.testSha256After, expected.testSha256);
assert.equal(receipt.headAfter, expected.head);
assert.equal(receipt.sourceTreeAfter, expected.sourceTree);
assert.equal(git('status', '--porcelain', '--', 'src', 'tests'), '');
console.log(JSON.stringify({ phase: 'terminal', ...receipt }));
process.exit(result.status ?? 1);
