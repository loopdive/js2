import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { readFileSync, mkdirSync, openSync, closeSync, writeFileSync } from 'node:fs';

const worker = '/private/tmp/js2-6915-linear-append-tests-20261007';
assert.equal(process.cwd(), worker);
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
assert.equal(git('branch', '--show-current'), 'codex/6915-linear-append-tests-20261007');
assert.equal(git('status', '--porcelain', '--', 'src'), '');
assert.equal(process.env.NODE_OPTIONS, undefined, 'Do not change the default heap configuration');
assert.ok(process.env.JS2WASM_LINEAR_IR === undefined || process.env.JS2WASM_LINEAR_IR === '1', 'Reject incompatible incoming IR flag');
const production = {
  runtime: '2a562751f9e2c6291944836681b3bc99b402c2d154a88c429ee16013eaf09e0f',
  consumer: '262d9866247af2e2fa18a6f8dbdf9d4a07c37c6ae188eb491a312949e6c60404',
  integration: '8bcc7d6507cb6abd1c4333e43fe5fef015f6649dd788221778aa61e6911c1571',
};
assert.equal(sha('src/codegen-linear/runtime.ts'), production.runtime);
assert.equal(sha('src/ir/backend/frozen-body-consumer.ts'), production.consumer);
assert.equal(sha('src/ir/backend/linear-integration.ts'), production.integration);
const sourceTree = git('rev-parse', 'HEAD:src');
assert.equal(sourceTree, '68296a0d34ceea94dbc9ca9398f71bc8a1b742b8');
const fixture = sha('website/public/benchmarks/competitive/programs/string-hash.js');
assert.equal(fixture, '66a15148fdd960dcbe5d87c25a28d870e8db9d00865483d708f0ca4e6e6e335c');
const args = ['exec', 'vitest', 'run', 'tests/issue-6915-linear-owned-ascii-append-copy-kernel.test.ts',
  '--pool=forks', '--poolOptions.forks.singleFork=true', '--no-file-parallelism',
  '--reporter=default', '--reporter=json', '--outputFile=.tmp/6915-validation/repaired-v2.json'];
const command = `pnpm ${args.join(' ')}`;
const expected = {
  ...production, sourceTree, fixture, head: git('rev-parse', 'HEAD'),
  testSha256: sha('tests/issue-6915-linear-owned-ascii-append-copy-kernel.test.ts'), command,
  effectiveFlags: { linearIr: '1', nodeOptions: null,
    execArgv: ['--max-old-space-size=1024', '--expose-gc', '--conditions', 'node', '--conditions', 'development'] },
};
mkdirSync('.tmp/6915-validation', { recursive: true });
writeFileSync('.tmp/6915-validation/repaired-v2-parent-input.json', JSON.stringify(expected, null, 2));
const log = openSync('.tmp/6915-validation/repaired-v2.log', 'w');
console.log(JSON.stringify({ phase: 'start', expected, incomingLinearIr: process.env.JS2WASM_LINEAR_IR ?? null }));
const result = spawnSync('pnpm', args, { stdio: ['ignore', log, log], env: {
  ...process.env, JS2WASM_LINEAR_IR: '1', JS2WASM_APPEND_TEST_COMMAND: command,
  JS2WASM_APPEND_EXPECTED_PROVENANCE: JSON.stringify(expected),
} });
closeSync(log);
const receipt = { status: result.status, signal: result.signal,
  error: result.error?.stack ?? null, expected, testSha256After: sha('tests/issue-6915-linear-owned-ascii-append-copy-kernel.test.ts') };
writeFileSync('.tmp/6915-validation/repaired-v2-parent-receipt.json', JSON.stringify(receipt, null, 2));
assert.equal(receipt.testSha256After, expected.testSha256, 'Instrument changed during execution');
console.log(JSON.stringify({ phase: 'terminal', ...receipt }));
process.exit(result.status ?? 1);
