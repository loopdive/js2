import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { compile } from '../src/index.js';
import { getLastLinearIrReport } from '../src/ir/backend/linear-integration.js';

const git = (...args: string[]) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const sha = (bytes: Uint8Array | string) => createHash('sha256').update(bytes).digest('hex');
const head = git('rev-parse', 'HEAD');
assert.equal(head, '3fee634ae67f23f57085ce6b792e584cd78e85ac');
assert.equal(git('rev-parse', 'HEAD:src'), '953f74f80cf2f8085b8e1c93489fcdd357929b37');
assert.equal(git('status', '--porcelain', '--', 'src'), '');
const runtimeHash = sha(readFileSync('src/codegen-linear/runtime.ts'));
console.log(JSON.stringify({ kind: 'provenance', head, sourceTree: git('rev-parse', 'HEAD:src'), runtimeHash, probeHash: sha(readFileSync('.tmp/6899-unicode-slice-probe.mts')), node: process.version, nativePolicy: 'unclassified; compatibility diagnostic only' }));
for (const mode of ['direct', 'overlay'] as const) {
  process.env.JS2WASM_LINEAR_IR = mode === 'overlay' ? '1' : '0';
  for (const text of ['ax', 'éx']) {
    const source = `export function run(start:number,end:number):number { return ${JSON.stringify(text)}.slice(start,end) === "x" ? 1 : 0; }`;
    const options = { target: 'linear' as const, optimize: false, experimentalIR: false, disableIrFirst: true, moduleName: 'issue-6899-unicode.ts' };
    try {
      const result = await compile(source, options);
      const report = getLastLinearIrReport();
      const row = { mode, text, source, sourceSha256: sha(source), options, args: [1, 2], native: text.slice(1, 2) === 'x' ? 1 : 0, success: result.success, errors: result.errors, compiled: mode === 'overlay' ? report?.compiled : null, rejected: mode === 'overlay' ? report?.rejected : null, valid: WebAssembly.validate(new Uint8Array(result.binary)), binaryHash: sha(result.binary) };
      if (!result.success) { console.log(JSON.stringify({ kind: 'row', ...row, actual: null })); continue; }
      const { instance } = await WebAssembly.instantiate(new Uint8Array(result.binary), result.importObject);
      const actual = (instance.exports.run as (a: number, b: number) => number)(1, 2);
      console.log(JSON.stringify({ kind: 'row', ...row, actual }));
    } catch (error) {
      console.log(JSON.stringify({ kind: 'row-error', mode, text, error: error instanceof Error ? { name: error.name, message: error.message } : String(error) }));
    }
  }
}
assert.equal(git('rev-parse', 'HEAD'), head);
assert.equal(sha(readFileSync('src/codegen-linear/runtime.ts')), runtimeHash);
assert.equal(git('status', '--porcelain', '--', 'src'), '');
console.log(JSON.stringify({ kind: 'terminal', sourceCustodyUnchanged: true, expectedRows: 4 }));
