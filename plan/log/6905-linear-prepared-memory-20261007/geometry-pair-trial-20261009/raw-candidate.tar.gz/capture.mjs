import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync, spawn } from "node:child_process";
import * as fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";
import { createRequire } from "node:module";

const HEAD = "0799a907eb8e6aaee3163420fed09fe0bfc61c3c";
const TREE = "fd543122e5c4f432ad332f2c617f13f4351b902f";
const ROOT = "/private/tmp/js2-6905-geometry-baseline-20261009";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const SELF = fileURLToPath(import.meta.url);
const TESTS = [
  "tests/issue-6905-linear-prepared-memory-materialization.test.ts",
  "tests/issue-3525-prepared-linear-early-return.test.ts",
];
const TEST_PINS = [
  "0afcb36a4cb3e783a06191bfe6356d568d96791d7aeca8249bfcdd580eac8d77",
  "8c3787b33a1d38dd42a261a1d8f40fdea10053a37816bef38c064f761387fd3d",
];
const IDS = [
  "native",
  "shared-scalar",
  "direct-allocation",
  "shared-allocation",
  "overlay-allocation",
  "unit-abi",
  "unit-freshness",
  "unit-runtime",
];
const LANES = [
  "native-JS",
  "Prepared-source",
  "direct-legacy",
  "Prepared-source-positive-requirement",
  "source-overlay-not-Prepared",
  "runtime-unit",
  "runtime-unit",
  "runtime-unit",
];
const ARCHIVE = "plan/log/6905-linear-prepared-memory-20261007/main-845/";
const FREEZE = path.join(HERE, "candidate-freeze.json");
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const cleanGitEnv = () => Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("GIT_")));
const git = (...args) =>
  execFileSync("git", args, { cwd: ROOT, env: cleanGitEnv(), maxBuffer: 64 * 1024 * 1024 }).toString();
const ENV_VALUES = {
  CI: ["true", "false", "1", "0"],
  NO_COLOR: ["1"],
  FORCE_COLOR: ["0", "1", "2", "3"],
  TERM: ["dumb", "xterm", "xterm-256color"],
  NODE_ENV: ["test", "development", "production"],
  TZ: ["UTC", "Europe/Berlin"],
  LANG: ["C", "C.UTF-8", "en_US.UTF-8", "en_GB.UTF-8", "de_DE.UTF-8"],
  LC_ALL: ["C", "C.UTF-8", "en_US.UTF-8"],
  LC_CTYPE: ["C", "UTF-8", "C.UTF-8", "en_US.UTF-8"],
};
function affectingEnv(env) {
  checkEnvironment(env);
  return Object.fromEntries(
    Object.keys(ENV_VALUES)
      .sort()
      .filter((key) => Object.hasOwn(env, key))
      .map((key) => [key, env[key]]),
  );
}
function checkEnvironment(env) {
  assert(!Object.hasOwn(env, "NODE_OPTIONS"), "NODE_OPTIONS must be absent, not overwritten");
  assert(!Object.hasOwn(env, "JS2WASM_LINEAR_IR"), "JS2WASM_LINEAR_IR must be absent, not overwritten");
  for (const key of Object.keys(env)) {
    if (Object.hasOwn(ENV_VALUES, key)) {
      assert(ENV_VALUES[key].includes(env[key]), "unsupported influencing environment value (not archived)");
    } else {
      assert(
        !/^(NODE|JS2WASM|VITE|TEST262|COMPILER|PNPM|COREPACK|NPM_CONFIG|LC_|ESBUILD|TSX|TS_NODE|BABEL|SWC)/i.test(key),
        "unsupported influencing environment setting (name/value not archived)",
      );
    }
  }
}
function selected(p) {
  // Conservative complete source/test/script census also captures test helpers and concurrency scripts.
  return (
    /^(src|tests|scripts)\//.test(p) ||
    /(^|\/)(package\.json|pnpm-lock\.yaml|pnpm-workspace\.yaml|(?:ts|js)config[^/]*\.json|(?:vite|vitest)[^/]*config[^/]*|vitest\.workspace[^/]*|\.?pnpmfile\.cjs|\.npmrc|\.nvmrc|\.node-version)$/.test(
      p,
    ) ||
    [ARCHIVE + "candidate25.json.gz", ARCHIVE + "candidate25.log.gz"].includes(p)
  );
}
function regular(root, relative) {
  assert(!path.isAbsolute(relative) && !relative.split("/").includes(".."));
  let current = root;
  const parts = relative.split("/");
  for (let i = 0; i < parts.length; i++) {
    current = path.join(current, parts[i]);
    const stat = fs.lstatSync(current);
    assert(!stat.isSymbolicLink(), `symlink input: ${relative}`);
    assert(i === parts.length - 1 ? stat.isFile() : stat.isDirectory(), `nonregular input: ${relative}`);
  }
  return fs.readFileSync(current);
}
function blobId(bytes) {
  return createHash("sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex");
}
function physicalEntry(root, entry) {
  assert(["100644", "100755"].includes(entry.mode), `nonregular Git mode: ${entry.path}`);
  const bytes = regular(root, entry.path);
  assert.equal(blobId(bytes), entry.blob, `physical/blob mismatch: ${entry.path}`);
  const mode = fs.statSync(path.join(root, entry.path)).mode;
  assert.equal(Boolean(mode & 0o111), entry.mode === "100755", `executable mode drift: ${entry.path}`);
  return { ...entry, bytes: bytes.length, sha256: sha(bytes) };
}
function checkPopulation(actual, approved, extras) {
  assert.deepEqual(actual, approved, "missing/extra committed input population");
  assert.deepEqual(extras, [], "extra physical input population");
}
function checkPins(files) {
  TESTS.forEach((p, i) => assert.equal(files.find((e) => e.path === p)?.sha256, TEST_PINS[i], `test pin: ${p}`));
}
function toolchain() {
  const resolve = createRequire(path.join(ROOT, "package.json"));
  const packages = ["vitest", "vite", "typescript"].map((name) => {
    const location = fs.realpathSync(resolve.resolve(`${name}/package.json`));
    const bytes = fs.readFileSync(location);
    return { name, path: location, version: JSON.parse(bytes).version, sha256: sha(bytes) };
  });
  const pnpmPath = execFileSync("which", ["pnpm"], { encoding: "utf8" }).trim();
  const binaries = [
    process.execPath,
    fs.realpathSync(pnpmPath),
    fs.realpathSync(path.join(ROOT, "node_modules/.bin/vitest")),
  ];
  return {
    node: process.version,
    v8: process.versions.v8,
    platform: process.platform,
    arch: process.arch,
    execPath: process.execPath,
    execArgv: process.execArgv,
    pnpm: execFileSync("pnpm", ["--version"], { encoding: "utf8", cwd: ROOT }).trim(),
    binaries: binaries.map((p) => ({ path: p, bytes: fs.statSync(p).size, sha256: sha(fs.readFileSync(p)) })),
    nodeModulesTarget: fs.realpathSync(path.join(ROOT, "node_modules")),
    packages,
  };
}
function snapshot() {
  checkEnvironment(process.env);
  assert.equal(fs.realpathSync(process.cwd()), ROOT, "wrong cwd");
  const head = git("rev-parse", "HEAD").trim(),
    sourceTree = git("rev-parse", "HEAD:src").trim();
  assert.equal(head, HEAD, "wrong HEAD");
  assert.equal(sourceTree, TREE, "wrong source tree");
  const entries = git("ls-tree", "-rz", "--full-tree", "HEAD")
    .split("\0")
    .filter(Boolean)
    .map((line) => {
      const match = /^(\d+) blob ([a-f0-9]{40})\t(.+)$/.exec(line);
      if (!match) {
        assert(!selected(line.split("\t")[1] || ""), "unsupported input tree entry");
        return null;
      }
      return { mode: match[1], blob: match[2], path: match[3] };
    })
    .filter((e) => e && selected(e.path));
  assert(entries.filter((e) => e.path.startsWith("src/")).length > 1900, "source population floor");
  assert.equal(git("diff", "--name-only", "HEAD", "--", ...entries.map((e) => e.path)), "", "dirty tracked input");
  // --ignored includes ignored extra source/test/script/config files; only node_modules and scratch are outside scope.
  const untracked = [
    ...git("ls-files", "--others", "--exclude-standard", "-z").split("\0"),
    ...git("ls-files", "--others", "--ignored", "--exclude-standard", "-z").split("\0"),
  ].filter((p) => p && selected(p));
  checkPopulation(entries, entries, untracked);
  const files = entries.map((entry) => physicalEntry(ROOT, entry));
  checkPins(files);
  return {
    head,
    sourceTree,
    cwd: ROOT,
    files,
    toolchain: toolchain(),
    environment: affectingEnv(process.env),
    environmentPolicy: "explicit-nonsecret-v2",
  };
}
function checkSnapshot(actual, approved) {
  checkPopulation(
    actual.files.map((e) => e.path),
    approved.files.map((e) => e.path),
    [],
  );
  assert.deepEqual(actual, approved, "custody drift");
}
const readArchive = (name) => gunzipSync(fs.readFileSync(path.join(ROOT, ARCHIVE + name))).toString("utf8");
function records(log) {
  assert(log === "" || log.endsWith("\n"), "unterminated raw output");
  const result = [];
  for (const line of log.split("\n")) {
    if (/"issue"\s*:\s*6905\b/.test(line) && !line.startsWith('{"issue":6905'))
      throw new Error("decorated/truncated observation record");
    if (line.startsWith('{"issue":6905')) result.push(JSON.parse(line));
  }
  return result;
}
function transportRecords(transport) {
  const stdout = records(transport.stdout),
    stderr = records(transport.stderr);
  // Cross-stream chronology is unknowable. A complete ordered population must reside in one stream.
  assert(!(stdout.length && stderr.length), "6905 records on both streams; no authenticated interleaving");
  return { stream: stdout.length ? "stdout" : "stderr", records: stdout.length ? stdout : stderr };
}
function historicalOracle() {
  const report = JSON.parse(readArchive("candidate25.json.gz"));
  const rec = records(readArchive("candidate25.log.gz"));
  return {
    names: report.testResults.flatMap((s) => s.assertionResults.map((a) => a.fullName)),
    provenance: rec.find((r) => r.kind === "provenance"),
    rows: rec.filter((r) => r.kind === "row"),
    statuses: report.testResults.flatMap((s) =>
      s.assertionResults.map((a) => ({ name: a.fullName, status: a.status, failureMessages: a.failureMessages })),
    ),
    rawFailureText: failureTransport({ stdout: readArchive("candidate25.log.gz"), stderr: "" }, report.numFailedTests),
  };
}
function failureTransport(transport, failed) {
  if (!failed) return { stdout: "", stderr: "" };
  assert.equal(
    (transport.stdout.match(/ FAIL /g) ?? []).length + (transport.stderr.match(/ FAIL /g) ?? []).length,
    failed,
    "missing/extra failure headings across raw streams",
  );
  assert.equal(
    (transport.stdout.match(/ Test Files /g) ?? []).length + (transport.stderr.match(/ Test Files /g) ?? []).length,
    1,
    "missing/duplicate Test Files footer",
  );
  const segment = (log) => {
    const start = log.indexOf(" FAIL ");
    if (start < 0) return "";
    const footer = log.indexOf(" Test Files ", start);
    return log.slice(start, footer < 0 ? log.length : footer);
  };
  return { stdout: segment(transport.stdout), stderr: segment(transport.stderr) };
}
function classify(result, errors) {
  if (
    result.spawnError ||
    result.signal ||
    result.timedOut ||
    result.outputError ||
    result.truncated ||
    result.closed === false ||
    errors.length
  )
    return "infrastructure-failure";
  if (result.code === 0) return "completed-green";
  if (result.code === 1) return "completed-red";
  return "infrastructure-failure";
}
function retainFailure(errors, stage, error) {
  // Explicit plain diagnostics; do not claim native Error serialization is lossless.
  errors.push({
    stage,
    name: error?.name ?? "Error",
    message: String(error?.message ?? error),
    stack: error?.stack ?? null,
  });
}
function cleanupAttempt(errors, stage, action) {
  try {
    action();
  } catch (e) {
    retainFailure(errors, stage, e);
  }
}
function validate(report, log, result, custody, oracle) {
  const transport = typeof log === "string" ? { stdout: log, stderr: "" } : log;
  assert.equal(classify(result, []), result.code === 0 ? "completed-green" : "completed-red");
  assert.equal(report.numTotalTests, 25);
  assert.equal(report.numPendingTests, 0);
  assert.equal(report.numTodoTests, 0);
  const suites = report.testResults;
  assert.equal(suites.length, 2);
  assert.deepEqual(suites.map((s) => path.relative(ROOT, s.name)).sort(), [...TESTS].sort());
  const assertions = suites.flatMap((s) => s.assertionResults);
  assert.equal(assertions.length, 25);
  assert.equal(new Set(assertions.map((a) => a.fullName)).size, 25);
  assert.deepEqual(assertions.map((a) => a.fullName).sort(), [...oracle.names].sort());
  assert(
    assertions.every((a) => ["passed", "failed"].includes(a.status)),
    "nonterminal assertion",
  );
  const passed = assertions.filter((a) => a.status === "passed").length,
    failed = 25 - passed;
  assert.equal(report.numPassedTests, passed);
  assert.equal(report.numFailedTests, failed);
  assert.equal(report.success, failed === 0);
  assert.equal(result.code, failed ? 1 : 0);
  assert(
    suites.every((s) => s.status === (s.assertionResults.some((a) => a.status === "failed") ? "failed" : "passed")),
  );
  const observed = transportRecords(transport),
    rec = observed.records;
  assert.equal(rec.length, 10);
  assert(rec.every((r) => r.issue === 6905 && r.schemaVersion === 1));
  const provenance = rec.filter((r) => r.kind === "provenance"),
    population = rec.filter((r) => r.kind === "population");
  const rows = rec.filter((r) => r.kind === "row");
  assert.equal(provenance.length, 1);
  assert.equal(population.length, 1);
  assert.deepEqual(
    rows.map((r) => r.id),
    IDS,
  );
  assert.deepEqual(
    rows.map((r) => r.lane),
    LANES,
  );
  assert.deepEqual(population[0].ids, IDS);
  assert.equal(population[0].count, 8);
  assert.equal(population[0].expected, 8);
  const p = provenance[0];
  assert.equal(p.head, custody.head);
  for (const [key, file] of [
    ["testSha256", TESTS[0]],
    ["runtimeSha256", "src/codegen-linear/runtime.ts"],
    ["helperSha256", "src/codegen-linear/runtime/vector-initialization.ts"],
  ])
    assert.equal(p[key], custody.files.find((e) => e.path === file)?.sha256);
  for (const key of [
    "baseline",
    "source",
    "sourceSha256",
    "scalarSource",
    "scalarSourceSha256",
    "logicalFile",
    "options",
    "expectedRows",
    "sourceRows",
    "initializerUnitRows",
    "execArgv",
    "nodeOptions",
  ])
    assert.deepEqual(p[key], oracle.provenance[key], `provenance mismatch ${key}`);
  assert.equal(p.node, custody.toolchain.node);
  assert.equal(p.v8, custody.toolchain.v8);
  rows.forEach((row, i) => {
    const name = oracle.names.filter((n) =>
      n.includes(
        [
          "native JavaScript independently",
          "shared Linear scalar is",
          "unchanged allocation source executes",
          "positive shared Linear allocation",
          "public single-source overlay owns",
          "registers the exact ABI",
          "allocates fresh body arrays",
          "executes fractional stores",
        ][i],
      ),
    );
    assert.equal(name.length, 1);
    assert.equal(row.status, assertions.find((a) => a.fullName === name[0]).status);
    assert(row.evidence && typeof row.evidence.phase === "string");
    assert(row.status === "passed" ? row.failure === null : typeof row.failure?.message === "string");
  });
  let binaries = 0;
  const visit = (value) => {
    if (!value || typeof value !== "object") return;
    if (Object.hasOwn(value, "binaryBase64")) {
      assert.equal(typeof value.binaryBase64, "string");
      const bytes = Buffer.from(value.binaryBase64, "base64");
      assert.equal(bytes.toString("base64"), value.binaryBase64, "noncanonical binary");
      assert.equal(bytes.length, value.byteLength);
      assert(bytes.length > 8);
      assert.equal(sha(bytes), value.sha256);
      assert.equal(value.valid, true);
      assert(WebAssembly.validate(bytes), "invalid binary");
      binaries++;
    }
    for (const child of Object.values(value)) visit(child);
  };
  visit(rows);
  assert.equal(binaries, 5);
  // Keep full raw observations/reporter/failures. No geometry or diagnostic normalization for acceptance.
  const differences = rows.flatMap((r, i) => {
    try {
      assert.deepEqual(r, oracle.rows[i]);
      return [];
    } catch {
      return [r.id];
    }
  });
  const statuses = assertions.map((a) => ({ name: a.fullName, status: a.status, failureMessages: a.failureMessages }));
  const rawFailureText = failureTransport(transport, failed);
  let statusesEqual = true;
  try {
    assert.deepEqual(statuses, oracle.statuses);
  } catch {
    statusesEqual = false;
  }
  return {
    assertions: 25,
    passed,
    failed,
    observations: rows.length,
    binaries,
    statuses,
    rawFailureText,
    statusesEqualToHistorical: statusesEqual,
    failureTextEqualToHistorical: JSON.stringify(rawFailureText) === JSON.stringify(oracle.rawFailureText),
    observationStream: observed.stream,
    preservationDifferences: differences,
    preservationAcceptance: false,
  };
}
function json(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + "\n", { flag: "wx" });
}
function latchFault(state, kind, notify) {
  if (kind === "timeout") {
    if (state.timedOut) return;
    state.timedOut = true;
  } else {
    if (state.outputError) return;
    state.outputError = kind;
    state.truncated = true;
  }
  notify({
    kind,
    childTerminationAuthorized: false,
    action: "keep draining; await natural close; parent attention required",
  });
}
function requireNaturalClose(state) {
  assert.equal(state.closed, true, "cannot finalize while child is live");
}
function captureChunk(state, fd, data, notify, write = fs.writeSync, cap = 256 * 1024 * 1024) {
  state.bytes += data.length;
  if (state.outputError) return; // Drain without buffering discarded bytes.
  const available = Math.max(0, cap - state.capturedBytes);
  const keep = data.subarray(0, available);
  try {
    let offset = 0;
    while (offset < keep.length) {
      const written = write(fd, keep, offset);
      assert(written > 0, "short zero write");
      offset += written;
      state.capturedBytes += written;
    }
  } catch {
    latchFault(state, "capture I/O failure", notify);
  }
  if (keep.length < data.length) latchFault(state, "output cap exceeded", notify);
}
async function childRun(args, directory) {
  const state = {
    code: null,
    signal: null,
    timedOut: false,
    spawnError: null,
    outputError: null,
    bytes: 0,
    capturedBytes: 0,
    truncated: false,
    closed: false,
  };
  const handles = [],
    cleanupErrors = [];
  let child, timer, closed;
  const notify = (notice) => {
    try {
      process.stderr.write(JSON.stringify({ parentNotice: notice }) + "\n");
    } catch (e) {
      retainFailure(cleanupErrors, "parent-notification", e);
    }
  };
  try {
    const out = fs.openSync(path.join(directory, "stdout.log"), "wx");
    handles.push(out);
    const err = fs.openSync(path.join(directory, "stderr.log"), "wx");
    handles.push(err);
    child = spawn("pnpm", args, {
      cwd: ROOT,
      env: { ...process.env },
      detached: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    closed = new Promise((resolve) =>
      child.on("close", (code, signal) => {
        state.code = code;
        state.signal = signal;
        state.closed = true;
        resolve();
      }),
    );
    const sink = (fd) => (data) => captureChunk(state, fd, data, notify);
    child.stdout.on("data", sink(out));
    child.stderr.on("data", sink(err));
    timer = setTimeout(() => latchFault(state, "timeout", notify), 600000);
    child.on("error", (e) => {
      state.spawnError = String(e.stack ?? e);
    });
    await closed;
  } catch (e) {
    state.spawnError = String(e.stack ?? e);
  } finally {
    // Never close captures, compare after-custody, or finalize receipts while the owned child is live.
    if (closed && !state.closed) await closed;
    if (closed) requireNaturalClose(state);
    clearTimeout(timer);
    for (const fd of handles) cleanupAttempt(cleanupErrors, "close-stream", () => fs.closeSync(fd));
  }
  state.droppedBytes = state.bytes - state.capturedBytes;
  return { state, cleanupErrors };
}
async function run(approvalPath) {
  // Parent's independently authored approval is mandatory; never selected from child outputs.
  const approval = JSON.parse(fs.readFileSync(approvalPath, "utf8"));
  assert.deepEqual(approval, {
    head: HEAD,
    sourceTree: TREE,
    freezeSha256: sha(fs.readFileSync(FREEZE)),
    instrumentSha256: sha(fs.readFileSync(SELF)),
    release: "one-candidate-diagnostic",
  });
  const approved = JSON.parse(fs.readFileSync(FREEZE, "utf8"));
  const oracle = historicalOracle();
  const directory = path.join(HERE, "candidate-once");
  fs.mkdirSync(directory); // Deliberately refuses any existing run directory; no overwrite/retry.
  const args = [
    "exec",
    "vitest",
    "run",
    ...TESTS,
    "--pool=forks",
    "--poolOptions.forks.singleFork=true",
    "--no-file-parallelism",
    "--reporter=default",
    "--reporter=json",
    `--outputFile=${path.relative(ROOT, directory)}/reporter.json`,
  ];
  const errors = [];
  let result = { code: null, signal: null, timedOut: false, spawnError: null, outputError: null, bytes: 0 };
  let before, after, summary;
  const start = Date.now();
  try {
    json(path.join(directory, "input.json"), {
      approved,
      approval,
      command: ["pnpm", ...args],
      cwd: process.cwd(),
      environment: affectingEnv(process.env),
      instrumentSha256: sha(fs.readFileSync(SELF)),
      freezeSha256: sha(fs.readFileSync(FREEZE)),
    });
    before = snapshot();
    checkSnapshot(before, approved);
    json(path.join(directory, "before.json"), before);
    const child = await childRun(args, directory);
    result = child.state;
    errors.push(...child.cleanupErrors);
    const report = JSON.parse(fs.readFileSync(path.join(directory, "reporter.json"), "utf8"));
    const log = fs.readFileSync(path.join(directory, "stdout.log"), "utf8");
    const stderr = fs.readFileSync(path.join(directory, "stderr.log"), "utf8");
    assert(
      !/Unhandled Error|unhandledRejection|Uncaught Exception|FATAL ERROR|ERR_IPC_CHANNEL_CLOSED/.test(log + stderr),
      "fatal/unhandled child error",
    );
    summary = validate(report, { stdout: log, stderr }, result, before, oracle);
    json(path.join(directory, "observations.json"), transportRecords({ stdout: log, stderr }));
    json(path.join(directory, "summary.json"), summary);
  } catch (e) {
    retainFailure(errors, "primary", e);
  } finally {
    try {
      after = snapshot();
      json(path.join(directory, "after.json"), after);
      checkSnapshot(after, approved);
    } catch (e) {
      retainFailure(errors, "after-custody", e);
    }
    try {
      assert.equal(sha(fs.readFileSync(SELF)), approval.instrumentSha256, "instrument drift");
      assert.equal(sha(fs.readFileSync(FREEZE)), approval.freezeSha256, "freeze drift");
    } catch (e) {
      retainFailure(errors, "instrument-custody", e);
    }
    try {
      json(path.join(directory, "errors.json"), errors);
    } catch (e) {
      retainFailure(errors, "errors-archive", e);
    }
    try {
      json(path.join(directory, "receipt.json"), {
        result,
        classification: classify(result, errors),
        elapsedMs: Date.now() - start,
        errors,
        summary: summary ?? null,
      });
    } catch (e) {
      retainFailure(errors, "receipt-archive", e);
    }
  }
  console.log(JSON.stringify({ directory, classification: classify(result, errors), result, summary, errors }));
  process.exitCode = classify(result, errors) === "infrastructure-failure" ? 2 : result.code;
}

function selfTest() {
  let count = 0;
  const control = (name, action) => {
    action();
    count++;
    console.log(`PASS ${name}`);
  };
  const base = {
    head: HEAD,
    sourceTree: TREE,
    files: [{ path: "src/a", sha256: "a" }],
    environment: {},
    toolchain: { node: "22" },
  };
  control("valid snapshot", () => checkSnapshot(base, structuredClone(base)));
  for (const key of ["head", "sourceTree", "files", "environment", "toolchain"])
    control(`custody ${key} drift`, () => {
      const bad = structuredClone(base);
      bad[key] = null;
      assert.throws(() => checkSnapshot(bad, base));
    });
  for (const key of ["NODE_OPTIONS", "JS2WASM_LINEAR_IR"])
    control(`present ${key} rejected`, () => assert.throws(() => checkEnvironment({ [key]: "" })));
  control("absent environment accepted", () => checkEnvironment({}));
  const terminal = { code: 1, signal: null, timedOut: false, spawnError: null, outputError: null };
  control("ordinary red preserved", () => assert.equal(classify(terminal, []), "completed-red"));
  for (const key of ["signal", "timedOut", "spawnError", "outputError"])
    control(`${key} infrastructure`, () =>
      assert.equal(classify({ ...terminal, [key]: true }, []), "infrastructure-failure"),
    );
  control("secondary error alongside primary", () => {
    const errors = [];
    retainFailure(errors, "primary", new Error("original"));
    cleanupAttempt(errors, "cleanup", () => {
      throw new Error("secondary");
    });
    assert.equal(errors.length, 2);
    assert.equal(errors[0].message, "original");
    assert.equal(classify(terminal, errors), "infrastructure-failure");
  });
  const fixture = fs.mkdtempSync(path.join(HERE, "controls-"));
  fs.mkdirSync(path.join(fixture, "src"));
  fs.writeFileSync(path.join(fixture, "src/a"), "inert");
  const entry = { path: "src/a", mode: "100644", blob: blobId(Buffer.from("inert")) };
  control("physical valid blob", () => physicalEntry(fixture, entry));
  control("physical changed blob", () =>
    assert.throws(() => physicalEntry(fixture, { ...entry, blob: "0".repeat(40) })),
  );
  control("physical missing", () => assert.throws(() => physicalEntry(fixture, { ...entry, path: "src/missing" })));
  fs.symlinkSync("a", path.join(fixture, "src/link"));
  control("physical symlink", () => assert.throws(() => physicalEntry(fixture, { ...entry, path: "src/link" })));
  control("extra source population", () => assert.throws(() => checkPopulation([entry], [entry], ["src/extra"])));
  control("missing committed config", () => assert.throws(() => checkPopulation([], [entry], [])));
  control("added committed config", () => assert.throws(() => checkPopulation([entry, entry], [entry], [])));
  for (const input of [...TESTS, "vitest.config.ts", "pnpm-lock.yaml"]) {
    control(`changed pin ${input}`, () => {
      const bad = structuredClone(base);
      bad.files = [{ path: input, sha256: "changed" }];
      assert.throws(() => checkSnapshot(bad, base));
    });
  }
  TESTS.forEach((p, i) =>
    control(`literal reviewed test pin ${p}`, () => {
      const files = TESTS.map((name, j) => ({ path: name, sha256: TEST_PINS[j] }));
      checkPins(files);
      files[i].sha256 = "0".repeat(64);
      assert.throws(() => checkPins(files));
    }),
  );
  control("after drift against original freeze", () => {
    const frozen = structuredClone(base),
      after = structuredClone(base);
    after.files[0].sha256 = "drift";
    assert.throws(() => checkSnapshot(after, frozen));
  });
  const oracle = historicalOracle(),
    report = JSON.parse(readArchive("candidate25.json.gz"));
  report.testResults.forEach((s) => (s.name = path.join(ROOT, "tests", path.basename(s.name))));
  const log = readArchive("candidate25.log.gz");
  const custody = {
    head: oracle.provenance.head,
    toolchain: { node: oracle.provenance.node, v8: oracle.provenance.v8 },
    files: [
      ["testSha256", TESTS[0]],
      ["runtimeSha256", "src/codegen-linear/runtime.ts"],
      ["helperSha256", "src/codegen-linear/runtime/vector-initialization.ts"],
    ].map(([k, p]) => ({ path: p, sha256: oracle.provenance[k] })),
  };
  control("actual historical 25/8/5 positive (not new qualification)", () =>
    validate(report, log, terminal, custody, oracle),
  );
  for (const mutation of [
    "missing assertion",
    "duplicate assertion",
    "missing row",
    "duplicate row",
    "corrupt binary",
  ]) {
    control(mutation, () => {
      const bad = structuredClone(report),
        rec = records(log);
      if (mutation === "missing assertion") bad.testResults[0].assertionResults.pop();
      if (mutation === "duplicate assertion")
        bad.testResults[0].assertionResults[1] = bad.testResults[0].assertionResults[0];
      if (mutation === "missing row") rec.splice(1, 1);
      if (mutation === "duplicate row") rec[2] = rec[1];
      if (mutation === "corrupt binary") rec.find((r) => r.id === "unit-abi").evidence.artifact.binaryBase64 = "AAAA";
      assert.throws(() =>
        validate(bad, rec.map((r) => JSON.stringify(r)).join("\n") + "\n", terminal, custody, oracle),
      );
    });
  }
  // Inert routing fixture: unchanged historical content placed according to Vitest's actual
  // stdout summary/stderr failure routing. This is not an observed new compiler execution.
  const failureStart = log.indexOf(" FAIL "),
    footer = log.lastIndexOf(" Test Files ");
  assert(failureStart >= 0 && footer > failureStart);
  const split = { stdout: log.slice(0, failureStart) + log.slice(footer), stderr: log.slice(failureStart, footer) };
  fs.writeFileSync(path.join(fixture, "split-stdout.log"), split.stdout, { flag: "wx" });
  fs.writeFileSync(path.join(fixture, "split-stderr.log"), split.stderr, { flag: "wx" });
  control("split stdout observations/footer + stderr FAIL ordinary red", () => {
    const summary = validate(report, split, terminal, custody, oracle);
    assert.equal(summary.failed, report.numFailedTests);
    assert.equal(summary.observationStream, "stdout");
    assert.equal(summary.rawFailureText.stderr, split.stderr);
    assert.equal(summary.rawFailureText.stdout, "");
  });
  for (const stream of ["stdout", "stderr"]) {
    for (const mutation of [
      "extra record",
      "duplicate population",
      "malformed record",
      "noncanonical record",
      "unterminated record",
    ]) {
      control(`${stream} ${mutation} rejected`, () => {
        const bad = { ...split };
        const extra =
          mutation === "duplicate population"
            ? JSON.stringify(records(log).at(-1))
            : mutation === "malformed record"
              ? '{"issue":6905,"kind":'
              : mutation === "noncanonical record"
                ? '{ "issue": 6905, "kind": "row" }'
                : '{"issue":6905,"schemaVersion":1,"kind":"unknown"}';
        bad[stream] += extra + (mutation === "unterminated record" ? "" : "\n");
        assert.throws(() => validate(report, bad, terminal, custody, oracle));
      });
    }
  }
  control("split missing stderr failure rejected", () =>
    assert.throws(() => validate(report, { ...split, stderr: "" }, terminal, custody, oracle)),
  );
  control("split duplicate footer rejected", () =>
    assert.throws(() =>
      validate(report, { ...split, stderr: split.stderr + " Test Files  1 failed\n" }, terminal, custody, oracle),
    ),
  );
  control("sentinel secret excluded without changing inherited object", () => {
    const env = {
      NO_COLOR: "1",
      TERM: "dumb",
      GH_TOKEN: "SENTINEL_SECRET_DO_NOT_ARCHIVE",
      AWS_SECRET_ACCESS_KEY: "SENTINEL_SECRET_DO_NOT_ARCHIVE",
    };
    const original = { ...env },
      projection = affectingEnv(env);
    assert.deepEqual(env, original);
    assert.deepEqual(projection, { NO_COLOR: "1", TERM: "dumb" });
    assert(!JSON.stringify(projection).includes("SENTINEL_SECRET"));
  });
  for (const key of ["npm_config_token", "NPM_CONFIG_PASSWORD", "VITEST_UNKNOWN", "NODE_PATH"]) {
    control(`${key} unsupported value never archived`, () => {
      try {
        affectingEnv({ [key]: "SENTINEL_SECRET_DO_NOT_ARCHIVE" });
        assert.fail("must refuse");
      } catch (e) {
        assert(!String(e.stack).includes("SENTINEL_SECRET"));
        assert(String(e.message).includes("unsupported influencing"));
      }
    });
  }
  control("unsupported projected value never archived", () => {
    assert.throws(() => affectingEnv({ TERM: "SENTINEL_SECRET_DO_NOT_ARCHIVE" }), /unsupported influencing/);
  });
  control("timeout latches and continues draining without termination", () => {
    const state = { ...terminal, bytes: 0, capturedBytes: 0, closed: false },
      notices = [];
    const notify = (n) => notices.push(n);
    latchFault(state, "timeout", notify);
    latchFault(state, "timeout", notify);
    captureChunk(state, 0, Buffer.from("raw"), notify, (_fd, b, offset) => b.length - offset);
    assert.equal(state.capturedBytes, 3);
    assert.equal(notices.length, 1);
    assert.throws(() => requireNaturalClose(state));
    state.closed = true;
    requireNaturalClose(state);
    assert.equal(classify(state, []), "infrastructure-failure");
  });
  control("cap truncates explicitly and drains subsequent data", () => {
    const state = { ...terminal, bytes: 0, capturedBytes: 0, closed: false },
      notices = [];
    let writes = 0;
    const writer = (_fd, b, offset) => {
      writes++;
      return b.length - offset;
    };
    captureChunk(state, 0, Buffer.from("abcdef"), (n) => notices.push(n), writer, 4);
    captureChunk(state, 0, Buffer.from("more"), (n) => notices.push(n), writer, 4);
    assert.equal(writes, 1);
    assert.equal(state.capturedBytes, 4);
    assert.equal(state.bytes, 10);
    assert.equal(state.truncated, true);
    assert.equal(notices.length, 1);
    assert.equal(classify(state, []), "infrastructure-failure");
  });
  control("capture write fault latches, then drains without retry", () => {
    const state = { ...terminal, bytes: 0, capturedBytes: 0, closed: false };
    let writes = 0;
    const writer = () => {
      writes++;
      throw new Error("inert I/O fault");
    };
    captureChunk(state, 0, Buffer.from("first"), () => {}, writer);
    captureChunk(state, 0, Buffer.from("second"), () => {}, writer);
    assert.equal(writes, 1);
    assert.equal(state.bytes, 11);
    assert.equal(state.truncated, true);
    assert.throws(() => requireNaturalClose(state));
  });
  console.log(JSON.stringify({ controls: count, compilerChildExecuted: false, retainedFixture: fixture }));
}
const mode = process.argv[2];
if (mode === "--inspect") console.log(JSON.stringify(snapshot()));
else if (mode === "--self-test") selfTest();
else if (mode === "--run" && process.argv.length === 4) await run(process.argv[3]);
else throw new Error("Use --self-test, --inspect, or parent-approved --run <independent-approval.json>");
