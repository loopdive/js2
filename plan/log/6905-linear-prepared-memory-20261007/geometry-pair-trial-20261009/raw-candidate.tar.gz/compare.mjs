import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync, spawn } from "node:child_process";
import * as fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { gunzipSync } from "node:zlib";
import { createRequire } from "node:module";
import { isDeepStrictEqual } from "node:util";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PINS_SHA = "31e80b035c67a5f2509356ebbfecd7579634344a72d42d0a905823cb3e6f482d";
const HELPER = "src/codegen-linear/runtime/vector-initialization.ts";
const BASE_HEAD = "cdde1880d00af27156751557739d5e2a4e5dcf35";
const BASE_TREE = "712bfef554321f3fe081f72bb89654d7dc6d8104";
const NEXT_HEAD = "0799a907eb8e6aaee3163420fed09fe0bfc61c3c";
const NEXT_TREE = "fd543122e5c4f432ad332f2c617f13f4351b902f";
const NEXT_ENTRY = {
  mode: "100644",
  blob: "31e34309e5d663f2e7c71621fac7460dbbed33fb",
  path: HELPER,
  bytes: 673,
  sha256: "8110f838a039fa4e24729c1f64182ac42dc648cbff27ab6067afb832e78780a0",
};
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
function read(file) {
  let current = path.parse(file).root;
  for (const segment of file.slice(current.length).split("/")) {
    current = path.join(current, segment);
    assert(!fs.lstatSync(current).isSymbolicLink(), "symlink packet input");
  }
  assert(fs.statSync(file).isFile(), "nonregular packet input");
  return fs.readFileSync(file);
}
function equal(left, right, location) {
  if (isDeepStrictEqual(left, right)) return;
  if (left && right && typeof left === "object" && typeof right === "object") {
    for (const key of new Set([...Object.keys(left), ...Object.keys(right)])) {
      if (!Object.hasOwn(left, key) || !Object.hasOwn(right, key)) {
        const error = new Error(`pair mismatch at ${location}.${key}`);
        error.difference = {
          path: `${location}.${key}`,
          leftPresent: Object.hasOwn(left, key),
          rightPresent: Object.hasOwn(right, key),
          left: left[key] === undefined ? { type: "undefined" } : left[key],
          right: right[key] === undefined ? { type: "undefined" } : right[key],
        };
        throw error;
      }
      equal(left[key], right[key], `${location}.${key}`);
    }
  }
  const error = new Error(`pair mismatch at ${location}`);
  error.difference = {
    path: location,
    left: left === undefined ? { type: "undefined" } : left,
    right: right === undefined ? { type: "undefined" } : right,
  };
  throw error;
}
function pins() {
  const bytes = read(path.join(HERE, "packet-pins.json"));
  assert.equal(sha(bytes), PINS_SHA, "fixed packet contract digest");
  return JSON.parse(bytes);
}
function requireDigest(bytes, expected) {
  assert.equal(sha(bytes), expected, "original packet digest mismatch");
}
function loadPredicates(contract) {
  const bytes = read(contract.instrument);
  requireDigest(bytes, contract.instrumentSha256);
  let source = bytes.toString("utf8");
  const startup = "const mode = process.argv[2];";
  assert.equal(source.split(startup).length, 2);
  // Disconnect CLI startup in memory only. Execute the exact reviewed production predicates,
  // not a copied validator, compiler import, or an executable packet-provided function.
  source = source
    .slice(0, source.indexOf(startup))
    .replace(/^import .*;\n/gm, "")
    .replaceAll("import.meta.url", JSON.stringify(pathToFileURL(contract.instrument).href));
  const functions = new Function(
    "assert",
    "createHash",
    "execFileSync",
    "spawn",
    "fs",
    "path",
    "fileURLToPath",
    "gunzipSync",
    "createRequire",
    source + "\nreturn {validate,transportRecords,historicalOracle,classify};",
  );
  return functions(assert, createHash, execFileSync, spawn, fs, path, fileURLToPath, gunzipSync, createRequire);
}
function frozenDelta(baseline, candidate) {
  assert.equal(baseline.head, BASE_HEAD);
  assert.equal(baseline.sourceTree, BASE_TREE);
  assert.equal(candidate.head, NEXT_HEAD);
  assert.equal(candidate.sourceTree, NEXT_TREE);
  const expected = structuredClone(baseline);
  expected.head = NEXT_HEAD;
  expected.sourceTree = NEXT_TREE;
  const old = baseline.files.find((e) => e.path === HELPER);
  equal(
    old,
    {
      mode: "100644",
      blob: "82deface9bac76ceaf218d7b5b519e05858fd622",
      path: HELPER,
      bytes: 666,
      sha256: "829df3c7d2b9de84c72fc82e3d316529fda368d72eebd5241d88f1c457ea0d97",
    },
    "baseline.initializer",
  );
  expected.files = expected.files.map((e) => (e.path === HELPER ? NEXT_ENTRY : e));
  equal(expected, candidate, "candidate.freeze");
}
function gitDelta(root) {
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("GIT_")));
  const git = (args) => execFileSync("git", args, { cwd: root, env, maxBuffer: 16 * 1024 * 1024 });
  equal(
    git(["diff", "--name-only", BASE_HEAD, NEXT_HEAD, "--", "src"]).toString().trim().split("\n"),
    [HELPER],
    "whole.source.delta",
  );
  equal(
    git(["rev-parse", `${BASE_HEAD}:src`])
      .toString()
      .trim(),
    BASE_TREE,
    "baseline.git.tree",
  );
  equal(
    git(["rev-parse", `${NEXT_HEAD}:src`])
      .toString()
      .trim(),
    NEXT_TREE,
    "candidate.git.tree",
  );
  const before = git(["show", `${BASE_HEAD}:${HELPER}`]),
    after = git(["show", `${NEXT_HEAD}:${HELPER}`]);
  equal(
    Buffer.from(
      after
        .toString()
        .replace("../../shared/contracts/linear-memory-layout.js", "../../ir/analysis/linear-memory-plan.js"),
    ),
    before,
    "exact.import.inverse",
  );
  equal(sha(after), NEXT_ENTRY.sha256, "candidate.git.helper");
}
function loadPacket(contract, expectedFiles) {
  equal(fs.readdirSync(contract.directory).sort(), expectedFiles, "packet.path.population");
  const files = Object.fromEntries(expectedFiles.map((name) => [name, read(path.join(contract.directory, name))]));
  const parse = (name) => JSON.parse(files[name]);
  const stdout = files["stdout.log"].toString("utf8"),
    stderr = files["stderr.log"].toString("utf8");
  equal(Buffer.from(stdout), files["stdout.log"], "stdout.UTF8.lossless");
  equal(Buffer.from(stderr), files["stderr.log"], "stderr.UTF8.lossless");
  return {
    files,
    input: parse("input.json"),
    before: parse("before.json"),
    after: parse("after.json"),
    errors: parse("errors.json"),
    reporter: parse("reporter.json"),
    observations: parse("observations.json"),
    receipt: parse("receipt.json"),
    summary: parse("summary.json"),
    transport: { stdout, stderr },
    parent: JSON.parse(read(contract.terminal)),
    approval: JSON.parse(
      read(contract.approvalPath ?? path.join(path.dirname(contract.instrument), "parent-approval.json")),
    ),
  };
}
function expectedCommand(contract, root) {
  return [
    "pnpm",
    "exec",
    "vitest",
    "run",
    "tests/issue-6905-linear-prepared-memory-materialization.test.ts",
    "tests/issue-3525-prepared-linear-early-return.test.ts",
    "--pool=forks",
    "--poolOptions.forks.singleFork=true",
    "--no-file-parallelism",
    "--reporter=default",
    "--reporter=json",
    `--outputFile=${path.relative(root, contract.directory)}/reporter.json`,
  ];
}
function binaryWitnesses(rows) {
  const witnesses = [];
  const visit = (value, location) => {
    if (!value || typeof value !== "object") return;
    if (Object.hasOwn(value, "binaryBase64")) {
      const bytes = Buffer.from(value.binaryBase64, "base64");
      equal(bytes.toString("base64"), value.binaryBase64, `${location}.base64`);
      equal(bytes.length, value.byteLength, `${location}.byteLength`);
      equal(sha(bytes), value.sha256, `${location}.sha256`);
      assert(WebAssembly.validate(bytes));
      witnesses.push({ path: location, bytes: Array.from(bytes), byteLength: value.byteLength, sha256: value.sha256 });
    }
    for (const [key, child] of Object.entries(value)) visit(child, `${location}.${key}`);
  };
  visit(rows, "rows");
  assert.equal(witnesses.length, 5, "five full binaries");
  return witnesses;
}
function verifyArm(packet, contract, frozen, root, predicates, release) {
  equal(packet.input.approved, frozen, "input.approved");
  equal(packet.before, frozen, "before.frozen");
  equal(packet.after, packet.before, "after.before");
  equal(frozen.head, contract.head, "frozen.head");
  equal(frozen.sourceTree, contract.sourceTree, "frozen.sourceTree");
  equal(packet.input.cwd, root, "input.cwd");
  equal(frozen.cwd, root, "frozen.cwd");
  equal(packet.input.environment, frozen.environment, "input.environment");
  equal(packet.input.instrumentSha256, contract.instrumentSha256, "input.instrumentSha256");
  equal(packet.input.freezeSha256, contract.freezeSha256, "input.freezeSha256");
  equal(
    packet.approval,
    {
      head: contract.head,
      sourceTree: contract.sourceTree,
      instrumentSha256: contract.instrumentSha256,
      freezeSha256: contract.freezeSha256,
      release,
    },
    "parent.approval",
  );
  equal(packet.input.approval, packet.approval, "input.approval");
  equal(packet.input.command, expectedCommand(contract, root), "command");
  equal(packet.errors, [], "errors");
  equal(packet.receipt.errors, [], "receipt.errors");
  const result = packet.receipt.result;
  equal(predicates.classify(result, []), "completed-red", "result.classification");
  equal(packet.receipt.classification, "completed-red", "receipt.classification");
  equal(result.code, 1, "child.exit");
  equal(result.signal, null, "child.signal");
  equal(result.closed, true, "child.closed");
  equal(result.truncated, false, "child.truncated");
  equal(result.timedOut, false, "child.timedOut");
  equal(result.spawnError, null, "child.spawnError");
  equal(result.outputError, null, "child.outputError");
  const rawBytes = Buffer.byteLength(packet.transport.stdout) + Buffer.byteLength(packet.transport.stderr);
  equal(result.bytes, rawBytes, "raw.bytes");
  equal(result.capturedBytes, rawBytes, "raw.capturedBytes");
  equal(result.droppedBytes, 0, "raw.droppedBytes");
  assert(
    !/Unhandled Error|unhandledRejection|Uncaught Exception|FATAL ERROR|ERR_IPC_CHANNEL_CLOSED/.test(
      packet.transport.stdout + packet.transport.stderr,
    ),
    "fatal child output",
  );
  const observations = predicates.transportRecords(packet.transport);
  equal(packet.observations, observations, "raw.records.archive");
  const oracle = predicates.historicalOracle();
  const summary = predicates.validate(packet.reporter, packet.transport, result, frozen, oracle);
  equal(packet.summary, summary, "summary.derived");
  equal(packet.receipt.summary, summary, "receipt.summary.derived");
  equal(packet.parent.parentExit, 1, "parent.exit");
  equal(packet.parent.childExit, 1, "parent.childExit");
  equal(packet.parent.classification, "completed-red", "parent.classification");
  equal(packet.parent.executions, 1, "parent.executions");
  equal(packet.parent.signal, null, "parent.signal");
  equal(packet.parent.timedOut, false, "parent.timedOut");
  equal(packet.parent.spawnError, null, "parent.spawnError");
  equal(packet.parent.truncated, false, "parent.truncated");
  equal(packet.parent.capturedBytes, rawBytes, "parent.capturedBytes");
  equal(packet.parent.droppedBytes, 0, "parent.droppedBytes");
  for (const key of ["assertions", "passed", "failed", "observations", "binaries"])
    equal(packet.parent[key], summary[key], `parent.${key}`);
  equal(packet.parent.custodyEqual, true, "parent.custodyEqual");
  const rows = observations.records.filter((r) => r.kind === "row"),
    provenance = observations.records.find((r) => r.kind === "provenance");
  const statuses = packet.reporter.testResults.flatMap((s) =>
    s.assertionResults.map((a) => ({ name: a.fullName, status: a.status, failureMessages: a.failureMessages })),
  );
  return {
    rows,
    binaries: binaryWitnesses(rows),
    statuses,
    failureText: summary.rawFailureText,
    completeStderr: packet.transport.stderr,
    provenance,
    summary,
  };
}
function compareArms(left, right) {
  equal(left.rows, right.rows, "rows");
  equal(left.binaries, right.binaries, "binaries");
  equal(left.statuses, right.statuses, "ordered.assertions");
  equal(left.failureText, right.failureText, "split.failureText");
  equal(left.completeStderr, right.completeStderr, "complete.stderr");
  equal(Object.keys(left.provenance), Object.keys(right.provenance), "provenance.keys");
  // Only these two independently joined identity fields differ; no observation/failure field is removed.
  for (const key of Object.keys(left.provenance))
    if (!["head", "helperSha256"].includes(key))
      equal(left.provenance[key], right.provenance[key], `provenance.${key}`);
  return {
    pairedPreservationEqual: true,
    orderedAssertions: 25,
    orderedRows: 8,
    completeBinaries: 5,
    baselineChildExit: 1,
    candidateChildExit: 1,
    nativeAcceptance: false,
  };
}
function verifyBaselinePins(contract) {
  requireDigest(read(contract.tar.path), contract.tar.sha256);
  const root = path.dirname(contract.baseline.instrument);
  for (const [name, digest] of Object.entries(contract.baseline.hashes)) {
    const bytes = read(path.join(root, name));
    requireDigest(bytes, digest);
    equal(
      execFileSync("tar", ["-xOzf", contract.tar.path, name], { maxBuffer: 16 * 1024 * 1024 }),
      bytes,
      `published.tar.${name}`,
    );
  }
}
function context() {
  const contract = pins();
  verifyBaselinePins(contract);
  requireDigest(read(contract.candidate.freeze), contract.candidate.freezeSha256);
  const baselineFreeze = JSON.parse(read(contract.baseline.freeze)),
    candidateFreeze = JSON.parse(read(contract.candidate.freeze));
  frozenDelta(baselineFreeze, candidateFreeze);
  gitDelta(contract.root);
  return {
    contract,
    baselineFreeze,
    candidateFreeze,
    baselinePredicates: loadPredicates(contract.baseline),
    candidatePredicates: loadPredicates(contract.candidate),
  };
}
function candidatePacketPins(contract, manifestPath, manifestDigest) {
  assert(/^[a-f0-9]{64}$/.test(manifestDigest ?? ""), "parent must separately supply candidate packet pin digest");
  const bytes = read(manifestPath);
  requireDigest(bytes, manifestDigest);
  const manifest = JSON.parse(bytes);
  equal(
    Object.keys(manifest).sort(),
    ["head", "sourceTree", "instrumentSha256", "freezeSha256", "hashes"].sort(),
    "candidate.parent-pin.schema",
  );
  for (const key of ["head", "sourceTree", "instrumentSha256", "freezeSha256"])
    equal(manifest[key], contract.candidate[key], `candidate.parent-pin.${key}`);
  const wanted = [
    ...contract.packetFiles.map((n) => `candidate-once/${n}`),
    "parent-terminal.json",
    "parent-approval.json",
  ].sort();
  equal(Object.keys(manifest.hashes).sort(), wanted, "candidate.parent-pin.population");
  for (const [name, digest] of Object.entries(manifest.hashes)) {
    assert(/^[a-f0-9]{64}$/.test(digest));
    requireDigest(read(path.join(path.dirname(contract.candidate.instrument), name)), digest);
  }
}
function selfTest() {
  const c = context(),
    { contract: p } = c;
  const baseline = loadPacket(p.baseline, p.packetFiles);
  const verifyBase = (packet) =>
    verifyArm(packet, p.baseline, c.baselineFreeze, p.root, c.baselinePredicates, "one-baseline-diagnostic");
  let count = 0;
  const control = (name, action) => {
    action();
    count++;
    console.log(`PASS ${name}`);
  };
  const baseArm = verifyBase(baseline);
  control("exact duplicate actual baseline packet positive", () =>
    compareArms(baseArm, verifyBase(structuredClone(baseline))),
  );
  const candidate = structuredClone(baseline);
  candidate.before = structuredClone(c.candidateFreeze);
  candidate.after = structuredClone(c.candidateFreeze);
  candidate.input.approved = structuredClone(c.candidateFreeze);
  candidate.approval = {
    head: p.candidate.head,
    sourceTree: p.candidate.sourceTree,
    instrumentSha256: p.candidate.instrumentSha256,
    freezeSha256: p.candidate.freezeSha256,
    release: "one-candidate-diagnostic",
  };
  candidate.input.approval = candidate.approval;
  candidate.input.instrumentSha256 = p.candidate.instrumentSha256;
  candidate.input.freezeSha256 = p.candidate.freezeSha256;
  candidate.input.command = expectedCommand(p.candidate, p.root);
  const provenance = candidate.observations.records[0];
  provenance.head = p.candidate.head;
  provenance.helperSha256 = NEXT_ENTRY.sha256;
  candidate.transport.stdout = candidate.transport.stdout
    .replace(`"head":"${BASE_HEAD}"`, `"head":"${NEXT_HEAD}"`)
    .replace(
      `"helperSha256":"829df3c7d2b9de84c72fc82e3d316529fda368d72eebd5241d88f1c457ea0d97"`,
      `"helperSha256":"${NEXT_ENTRY.sha256}"`,
    );
  const verifyCandidate = (packet) =>
    verifyArm(packet, p.candidate, c.candidateFreeze, p.root, c.candidatePredicates, "one-candidate-diagnostic");
  control("inert authorized identity/helper changes joined (not candidate execution)", () =>
    compareArms(baseArm, verifyCandidate(candidate)),
  );
  for (const [name, mutate] of [
    ["wrong HEAD", (x) => (x.before.head = "0".repeat(40))],
    ["wrong tree", (x) => (x.before.sourceTree = "0".repeat(40))],
    ["wrong helper", (x) => (x.before.files.find((e) => e.path === HELPER).sha256 = "0".repeat(64))],
    ["extra changed input", (x) => (x.before.files[0].sha256 = "0".repeat(64))],
    ["missing assertion", (x) => x.reporter.testResults[0].assertionResults.pop()],
    [
      "duplicate assertion",
      (x) => (x.reporter.testResults[0].assertionResults[1] = x.reporter.testResults[0].assertionResults[0]),
    ],
    ["missing row", (x) => x.observations.records.splice(1, 1)],
    ["duplicate row", (x) => (x.observations.records[2] = x.observations.records[1])],
    ["raw-record archive mismatch", (x) => (x.observations.stream = "stderr")],
    ["after drift", (x) => (x.after.files[0].sha256 = "0".repeat(64))],
    ["timeout", (x) => (x.receipt.result.timedOut = true)],
    ["truncation", (x) => (x.receipt.result.truncated = true)],
    ["infrastructure fault", (x) => (x.receipt.result.outputError = "fault")],
    ["parent terminal mismatch", (x) => (x.parent.parentExit = 0)],
  ])
    control(name, () => {
      const bad = structuredClone(candidate);
      mutate(bad);
      assert.throws(() => verifyCandidate(bad));
    });
  const candidateArm = verifyCandidate(candidate);
  for (const [name, mutate] of [
    ["nested row mutation", (x) => (x.rows[0].evidence.actual = 999)],
    ["missing binary", (x) => x.binaries.pop()],
    ["duplicate binary", (x) => (x.binaries[1] = x.binaries[0])],
    ["full binary byte mutation", (x) => (x.binaries[0].bytes[0] ^= 1)],
    ["changed status", (x) => (x.statuses[0].status = "failed")],
    [
      "changed failure/stack",
      (x) => (x.statuses.find((a) => a.status === "failed").failureMessages[0] += "changed-stack"),
    ],
    ["stdout failure segment", (x) => (x.failureText.stdout += "changed")],
    ["stderr failure segment", (x) => (x.failureText.stderr += "changed")],
    ["stderr error heading/prefix", (x) => (x.completeStderr = "changed-heading\n" + x.completeStderr)],
  ])
    control(name, () => {
      const bad = structuredClone(candidateArm);
      mutate(bad);
      assert.throws(() => compareArms(baseArm, bad));
    });
  control("original baseline digest mutation", () => {
    const bytes = read(path.join(p.baseline.directory, "stdout.log"));
    bytes[0] ^= 1;
    assert.throws(() => requireDigest(bytes, p.baseline.hashes["baseline-once/stdout.log"]));
  });
  control("unauthorized frozen input delta", () => {
    const bad = structuredClone(c.candidateFreeze);
    bad.files[0].sha256 = "0".repeat(64);
    assert.throws(() => frozenDelta(c.baselineFreeze, bad));
  });
  control("missing independent candidate packet pins rejected", () =>
    assert.throws(() => candidatePacketPins(p, "unused", undefined)),
  );
  console.log(
    JSON.stringify({
      controls: count,
      compilerChildExecuted: false,
      actualBaselineValidated: true,
      candidateFixturesAreInert: true,
    }),
  );
}
try {
  if (process.argv[2] === "--self-test") selfTest();
  else if (process.argv[2] === "--compare") {
    const c = context(),
      p = c.contract;
    candidatePacketPins(p, process.argv[3], process.argv[4]);
    const baseline = loadPacket(p.baseline, p.packetFiles),
      candidate = loadPacket(p.candidate, p.packetFiles);
    const left = verifyArm(
      baseline,
      p.baseline,
      c.baselineFreeze,
      p.root,
      c.baselinePredicates,
      "one-baseline-diagnostic",
    );
    const right = verifyArm(
      candidate,
      p.candidate,
      c.candidateFreeze,
      p.root,
      c.candidatePredicates,
      "one-candidate-diagnostic",
    );
    const result = compareArms(left, right);
    verifyBaselinePins(p);
    candidatePacketPins(p, process.argv[3], process.argv[4]);
    console.log(
      JSON.stringify({
        ...result,
        baselineHead: p.baseline.head,
        candidateHead: p.candidate.head,
        reporterOutputPathDifference: {
          baseline: expectedCommand(p.baseline, p.root).at(-1),
          candidate: expectedCommand(p.candidate, p.root).at(-1),
        },
      }),
    );
  } else
    throw new Error(
      "Use --self-test or parent-invoked --compare <independent-candidate-packet-pins.json> <approved-SHA256> after the separately released candidate",
    );
} catch (error) {
  console.error(
    JSON.stringify({
      acceptance: false,
      message: error.message,
      difference: error.difference ?? null,
      stack: error.stack,
    }),
  );
  process.exitCode = 1;
}
